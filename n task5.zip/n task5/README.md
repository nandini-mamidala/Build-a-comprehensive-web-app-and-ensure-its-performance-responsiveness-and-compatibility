# LiteShop — Final Project
A fast, responsive, cross‑browser demo e‑commerce web app using only HTML, CSS, and JavaScript.

## Highlights
- Minified CSS/JS, lazy‑loaded images, tiny SVG placeholders
- Client‑side routing via hash, dynamic catalog fetched from `products.json`
- Cart with `localStorage` persistence
- Accessible (labels, roles, focus states, reduced motion)
- Service Worker cache for offline-first loading
- No frameworks = fewer HTTP requests

## Run
Just open `index.html` in a browser. For full Service Worker support, serve via a static server (e.g., `python -m http.server`).

## Test
- Chrome, Firefox, Safari, Edge (latest)
- Resize to verify mobile layout
- Try search, sort, category filter, add/remove cart items
